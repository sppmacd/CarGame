#include "GuiMainMenu.h"
#include "../Game.h"
#include "../GameDisplay.h"
#include <iostream>

using namespace std;

Button GuiMainMenu::b1;
Button GuiMainMenu::b2;
Button GuiMainMenu::b3;

void GuiMainMenu::onLoad()
{
    GameDisplay* game = GameDisplay::instance;

    addButton(b1 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 - 60), "New Game", 0));
    addButton(b2 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2), "Settings", 2));
    addButton(b3 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 + 60), "Quit Game", 1));
    b3.setColor(sf::Color::Red);
}

void GuiMainMenu::drawGui(sf::RenderWindow* wnd)
{
    b1.draw(wnd);
    b2.draw(wnd);
    b3.draw(wnd);

    sf::Text text = drawString("Car Game", 200, sf::Vector2f(wnd->getSize().x / 2 - 300, 200), sf::Text::Italic);
    text.setFillColor(sf::Color(100, 0, 0));
    wnd->draw(text);
}

void GuiMainMenu::onButtonClicked(long button)
{
    Game* game = Game::instance;

    if(button == 0)
    {
        game->displayGui(4); //level selection
        if(game->isNewPlayer && game->tutorialStep == 2)
        {
            game->tutorialStep = 3;
        }
    }

    if(button == 1)
    {
        game->exit(0);
    }

    if(button == 2)
    {
        game->displayGui(3); //settings
    }
}

