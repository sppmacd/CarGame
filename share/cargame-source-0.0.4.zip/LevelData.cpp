#include "LevelData.h"
#include "maptype.h"

LevelData Maps::countryside;
LevelData Maps::desert;
LevelData Maps::forest;
LevelData Maps::ice;
LevelData Maps::mountains;

void LevelData::addRarity(Car::TypeId car, int value)
{
    this->carRarity.at(car) = value;
}

float LevelData::getAcceleration()
{
    return this->acc;
}

int LevelData::getCarRarity(Car::TypeId car)
{
    if(this->carRarity[car] != 0)
        return this->carRarity[car];
    else
        return 10; //default rarity
}

sf::Color LevelData::getColor()
{
    return this->mapColor;
}

LevelData::MapType LevelData::getMapType()
{
    return this->mapType;
}

sf::String LevelData::getTextureName()
{
    return this->textureName;
}

LevelData::LevelData(MapType type)
{
    this->mapType = type;
}

void LevelData::init()
{
    Maps::countryside = LevelData(COUNTRYSIDE);
    Maps::countryside.addRarity(Car::LORRY, 3);
    Maps::countryside.addRarity(Car::RARE, 5);
    Maps::countryside.addRarity(Car::BUS, 10);
    Maps::countryside.addRarity(Car::AMBULANCE, 10);
    Maps::countryside.setAcceleration(4);
    Maps::countryside.setColor(sf::Color::Green);
    Maps::countryside.setTextureName("countryside");

    Maps::desert.addRarity(Car::LORRY, 3);
    Maps::desert.addRarity(Car::RARE, 2);
    Maps::desert.addRarity(Car::BUS, 3);
    Maps::desert.addRarity(Car::AMBULANCE, 3);
    Maps::desert.setAcceleration(3.4);
    Maps::desert.setColor(sf::Color::Yellow);
    Maps::desert.setTextureName("desert");

    Maps::forest = LevelData(LevelData::FOREST);
    Maps::forest.addRarity(Car::LORRY, 3);
    Maps::forest.addRarity(Car::RARE, 2);
    Maps::forest.addRarity(Car::BUS, 15);
    Maps::forest.addRarity(Car::AMBULANCE, 10);
    Maps::forest.setAcceleration(5);
    Maps::forest.setColor(sf::Color(0, 140, 0));
    Maps::forest.setTextureName("forest");

    Maps::ice = LevelData(LevelData::ICE);
    Maps::ice.addRarity(Car::LORRY, 15);
    Maps::ice.addRarity(Car::RARE, 3);
    Maps::ice.addRarity(Car::BUS, 8);
    Maps::ice.addRarity(Car::AMBULANCE, 15);
    Maps::ice.setAcceleration(6);
    Maps::ice.setColor(sf::Color(230, 230, 230));
    Maps::ice.setTextureName("ice");

    Maps::mountains = LevelData(LevelData::MOUNTAINS);
    Maps::mountains.addRarity(Car::LORRY, 13);
    Maps::mountains.addRarity(Car::RARE, 7);
    Maps::mountains.addRarity(Car::BUS, 3);
    Maps::mountains.addRarity(Car::AMBULANCE, 20);
    Maps::mountains.setAcceleration(3);
    Maps::mountains.setColor(sf::Color(85, 86, 85));
    Maps::mountains.setTextureName("mountains");
}

void LevelData::setAcceleration(float f)
{
    this->acc = f;
}

void LevelData::setColor(sf::Color c)
{
    this->mapColor = c;
}

void LevelData::setTextureName(sf::String name)
{
    this->textureName = name;
}
