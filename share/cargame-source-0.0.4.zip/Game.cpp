#include "Game.h"
#include "CarLorry.h"
#include "CarRare.h"
#include <cmath>
#include <iostream>
#include <fstream>
#include "Gui.h"
#include "GuiGameOver.h"
#include "GuiIngame.h"
#include "GuiMainMenu.h"
#include "GuiSettings.h"
#include "GameDisplay.h"
#include "GuiMapSelect.h"
#include "GuiPowers.h"

Game* Game::instance;

Game::Game()
    : displayedGui(-1)
{
    cout << "Game: Started loading game engine..." << endl;

    GameDisplay::drawLoadingProgress("Loading game data...", GameDisplay::instance->getRenderWnd());

    this->mainTickCount = 0;
    this->running = true;
    instance = this;
    this->pause(true);
    this->isNewPlayer = false;
    this->tutorialStep = 0;

    LevelData::init();

    this->powers = new int[3];

    this->powerCooldown = 0;
    this->powerTime = 0;

    this->loadHighScore();
    this->debug = false;
    this->isPowerUsed = false;

    // Displays the main menu
    this->displayGui(2);
}

void Game::wheelEvent(sf::Event::MouseWheelScrollEvent event)
{
    int powercount = 2;

    if(!this->isGuiLoaded && this->powerTime <= 0)
    {
        if(event.delta > 0.f)
        {
            this->currentPower++;
            if(this->currentPower > powercount) this->currentPower = 1;
        }
        else if(event.delta < 0.f)
        {
            --this->currentPower;
            if(this->currentPower < 1) this->currentPower = powercount;
        }
    }
}

void Game::getPower(int id)
{
    this->powers[id]++;
}

void Game::usePower(int id)
{
    if(this->powers[id] > 0)
        this->powers[id]--;
}

int  Game::getCurrentPower()
{
    return this->currentPower;
}

void Game::addScore(int s)
{
    this->score += s;
    this->totalPlayerPoints += s;
    this->pointsToNewMpl -= s;
}

long Game::getTotalPoints()
{
    return this->totalPlayerPoints;
}

int Game::getCoinMultiplier()
{
    return this->coinMpl;
}

void Game::loadHighScore()
{
    GameDisplay::drawLoadingProgress("Loading player data...", GameDisplay::instance->getRenderWnd());

    cout << "Game: Loading player data..." << endl;

    std::ifstream file;
    file.open("data.txt");

    if(file.good())
    {
        cout << "Game: Player data read from data.txt" << endl;

        file
        >> this->highScore
        >> this->playerCoins
        >> this->unlockedLevels
        >> this->totalPlayerPoints
        >> this->coinMpl
        >> this->pointsToNewMpl
        >> this->powers[1]
        >> this->powers[2];
    }
    else
    {
        file.open("highscore.txt");

        if(file.good())
        {
            cout << "Game: Couldn't load data.txt! Converting from old player data format..." << endl;
            file
            >> this->highScore
            >> this->playerCoins
            >> this->unlockedLevels
            >> this->totalPlayerPoints
            >> this->coinMpl
            >> this->pointsToNewMpl
            >> this->powers[1]
            >> this->powers[2];
        }
        else
        {
            cout << "Game: Cannot load player data! Creating new profile. You are the new player :)" << endl;
            this->highScore = 0;
            this->playerCoins = 0;
            this->unlockedLevels = 0b0;
            this->totalPlayerPoints = 0;
            this->coinMpl = 1;
            this->pointsToNewMpl = 200;
            this->isNewPlayer = true;
            this->tutorialStep = 2;
            this->powers = new int[3];
            this->powers[1] = 0;
            this->powers[2] = 0;
        }
    }
}

void Game::saveHighScore()
{
    cout << "Game: Saving player data in data.txt..." << endl;

    GameDisplay::drawLoadingProgress("Saving player data...", GameDisplay::instance->getRenderWnd());

    std::ofstream file;
    file.open("data.txt");

    file << this->highScore << " "
    << this->getCoins() << " "
    << this->unlockedLevels << " "
    << this->totalPlayerPoints << " "
    << this->coinMpl << " "
    << this->pointsToNewMpl << " "
    << this->powers[1] << " "
    << this->powers[2] << " ";
}

void Game::loadGame(LevelData level)
{
    GameDisplay::drawLoadingProgress("Loading level " + level.getMapType(), GameDisplay::instance->getRenderWnd());

    cout << "Game: Loading level " << level.getMapType() << "..." << endl;

    this->level = level;

    this->lastTickScore = 0;
    this->cameraPos = 0;
    this->tickCount = 0;
    this->gameSpeed = level.getAcceleration() / 2.2;
    this->score = 0;
    this->gameOver = false;
    this->isGuiLoaded = false;
    this->cars.clear();
    this->pause(false);
    this->closeGui();
    this->currentPower = 0;
}

void Game::loadGame()
{
    GameDisplay::drawLoadingProgress("Reloading current level...", GameDisplay::instance->getRenderWnd());

    cout << "Game: Reloading current level..." << endl;

    this->lastTickScore = 0;
    this->cameraPos = 0;
    this->tickCount = 0;
    this->gameSpeed = this->level.getAcceleration() / 2.2;
    this->score = 0;
    this->gameOver = false;
    this->isGuiLoaded = false;
    this->cars.clear();
    this->pause(false);
    this->closeGui();
    this->currentPower = 0;
}

void Game::closeLevel()
{
    cout << "Game: Closing level..." << endl;
    GameDisplay::drawLoadingProgress("Closing level...", GameDisplay::instance->getRenderWnd());
    if(!this->cars.empty()) this->cars.clear();
    this->tickCount = 0;
    this->pause(true);
}

Game::~Game()
{
    cout << "Game: Deleting game engine instance..." << endl;
    this->closeLevel();
}

void Game::tickGui(sf::Event& event)
{
    this->tickEventMouseMove(sf::Vector2f(sf::Mouse::getPosition(*GameDisplay::instance->getRenderWnd())));

    if(event.type == sf::Event::MouseButtonPressed)
    {
        this->tickEventMouseClick(sf::Vector2f(sf::Mouse::getPosition(*GameDisplay::instance->getRenderWnd())));
    }
}

void Game::tickEventMouseMove(sf::Vector2f pos)
{
    if(this->isGuiLoaded)
    {
        Gui::onMouseMove(pos);
    }
}

void Game::tickEventMouseClick(sf::Vector2f pos)
{
    if(this->isGuiLoaded)
    {
        Gui::onButtonClicked(Gui::onMouseClick(pos).id);

        switch(this->displayedGui)
        {
        case 0:
            GuiIngame::onButtonClicked(Gui::onMouseClick(pos).id);
            break;
        case 1:
            GuiGameOver::onButtonClicked(Gui::onMouseClick(pos).id);
            break;
        case 2:
            GuiMainMenu::onButtonClicked(Gui::onMouseClick(pos).id);
            break;
        case 3:
            GuiSettings::onButtonClicked(Gui::onMouseClick(pos).id);
            break;
        case 4:
            GuiMapSelect::onButtonClicked(Gui::onMouseClick(pos).id);
            break;
        case 5:
            GuiPowers::onButtonClicked(Gui::onMouseClick(pos).id);
            break;
        default:
            cout << "Game: Undefined gui instance! Closing gui..." << endl;
            this->closeGui();
        }
    }
}

void Game::setGameOver()
{
    cout << "Game: Setting game over..." << endl;
    this->gameOver = true;
    this->saveHighScore();
    this->displayGui(1);
}

void Game::moveCamera()
{
    this->cameraPos += this->gameSpeed * 4.5;
}

void Game::displayGui(int gui)
{
    cout << "Game: Displaying gui "<< gui << endl;
    this->displayedGui = gui;

    Gui::onClose();

    if(gui == 0)
        GuiIngame::onLoad();
    else if(gui == 1)
        GuiGameOver::onLoad();
    else if(gui == 2)
        GuiMainMenu::onLoad();
    else if(gui == 3)
        GuiSettings::onLoad();
    else if(gui == 4)
        GuiMapSelect::onLoad();
    else if(gui == 5)
        GuiPowers::onLoad();

    this->isGuiLoaded = true;
    this->guiCooldown = 50;
}

void Game::closeGui()
{
    cout << "Game: Closing gui..." << endl;
    Gui::onClose();
    this->displayedGui = -1;
    this->isGuiLoaded = false;
}

void Game::toggleFullscreen()
{
    sf::RenderWindow* wnd = GameDisplay::instance->getRenderWnd();

    if(this->fullscreen)
    {
        wnd->close();
        wnd->create(sf::VideoMode(1920, 1080, 32), "Car Game");
        this->fullscreen = false;
    }
    else
    {
        wnd->close();
        wnd->create(sf::VideoMode(), sf::String(), sf::Style::Fullscreen);
        this->fullscreen = true;
    }
}

void Game::addCoins(long v)
{
    this->playerCoins += v;
}

void Game::removeCoins(long v)
{
    this->playerCoins -= v;
}

long Game::getCoins()
{
    return this->playerCoins;
}

bool Game::isLevelUnlocked(LevelData::MapType type)
{
    return (this->unlockedLevels >> type) & 0x1;
}

bool Game::isRunning()
{
    return this->running;
}

void Game::exit(int ret)
{
    cout << "Game: Handling exit()..." << endl;
    this->running = false;
    this->retVal = ret;
}
