#ifndef GAME_H
#define GAME_H

#include <vector>
#include "Car.h"
#include "Gui.h"
#include "LevelData.h"

using namespace std;

class Game
{
public:
    struct Times
    {
        sf::Time timeEvent;
        sf::Time timeTick;
        sf::Time timeRender;
        sf::Time timeGui;
        sf::Time timeWait;
    };

    static Game* instance;
    int tickCount;
    long mainTickCount;
    bool wasReleased;
    bool isGuiLoaded;
    int displayedGui;
    int guiCooldown;
    int powerTime;
    int powerCooldown;
    LevelData level;
    int retVal;
    Times times;
    bool isPowerUsed;

    /// PLAYER DATA ///
    int pointsToNewMpl;
    long lastTickScore;
    long highScore;
    bool isNewPlayer; //is the player started game first one
    int tutorialStep;

    sf::Time tickTime;
    sf::Time realTickTime;
    bool debug;

    ///saved in bytes :D
    int unlockedLevels;

    Game();
    virtual ~Game();

    vector<Car> cars;
    void addCar(Car car);
    void updateCars();
    void moveCamera();
    void updateEffect();
    void loadGame(LevelData level);
    void loadGame();
    void closeLevel();
    void tickNormalGame();

    /// \brief Rename to loadPlayerData()! Loads player data
    void loadHighScore();

    /// \brief Rename to savePlayerData()! Saves player data
    void saveHighScore();

    void newTick();
    bool isGameOver() { return this->gameOver; }
    int getScore() { return this->score; }
    void setGameOver();
    void pause(bool s) { this->gamePaused = s; }
    bool paused() { return this->gamePaused; }
    void tickGui(sf::Event& event);
    void toggleFullscreen();
    void addCoins(long v);
    void removeCoins(long v);
    long getCoins();
    void displayGui(int gui);
    void closeGui();
    sf::Color getLevelColor() { return this->level.getColor(); }
    bool isLevelUnlocked(LevelData::MapType lvl);
    bool isRunning();
    void exit(int ret);
    long getTotalPoints();
    int getCoinMultiplier();
    void addScore(int s);
    void wheelEvent(sf::Event::MouseWheelScrollEvent event);
    int getCurrentPower();
    void getPower(int id);
    void usePower(int id);
    int* powers;

protected:

private:
    int cameraPos;
    float gameSpeed;
    bool gameOver;
    bool gamePaused;
    bool fullscreen;

    bool running;

    /// PLAYER DATA ///
    long totalPlayerPoints;
    int coinMpl;
    long playerCoins;
    long score;
    int currentPower;

    void tickEventMouseMove(sf::Vector2f pos);
    void tickEventMouseClick(sf::Vector2f pos);
};

#endif // GAME_H
