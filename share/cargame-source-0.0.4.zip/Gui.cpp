#include "Gui.h"
#include "GameDisplay.h"
#include "GameSound.h"
#include <cmath>

vector<Button*> Gui::buttons;

void Gui::addButton(Button& button)
{
    buttons.push_back(&button);
}

Button Gui::onMouseClick(sf::Vector2f vec)
{
    for(unsigned int i = 0; i < buttons.size(); i++)
    {
        if(sf::Rect<float>(buttons[i]->getPos(), buttons[i]->getSize()).contains(vec) && buttons[i]->enabled)
        {
            sf::Sound s(GameSound::instance->getBuffer(0));
            s.play();
            return *buttons[i];
        }
    }

    return Button();
}

void Gui::onClose()
{
    buttons.clear();
}

void Gui::onMouseMove(sf::Vector2f vec)
{
    for(unsigned int i = 0; i < buttons.size(); i++)
    {
        if(sf::Rect<float>(buttons[i]->getPos(), buttons[i]->getSize()).contains(vec))
        {
            buttons[i]->isMouseOver = true;
        }
        else
        {
            buttons[i]->isMouseOver = false;
        }
    }
}

void Gui::onButtonClicked(long button)
{

}

void Gui::drawGui(sf::RenderWindow* wnd)
{
    sf::RectangleShape rect((sf::Vector2f) wnd->getSize());
    rect.setFillColor(sf::Color(25, 20, 20, 200));
    wnd->draw(rect);
}

sf::Text Gui::drawString(string tx, int height, sf::Vector2f pos, sf::Text::Style style)
{
    return GameDisplay::instance->drawString(tx, height, pos, style);
}
