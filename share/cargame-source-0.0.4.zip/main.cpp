#include <SFML/Graphics.hpp>
#include "Game.h"
#include "GameDisplay.h"
#include "GuiIngame.h"
#include "GameSound.h"
#include <cstdlib>
#include <iostream>
#include <string>
#include <ctime>


using namespace std;

void loop(Game* game)
{
    if(!game->paused())
        game->tickNormalGame();

    game->newTick();
}

int main()
{
    sf::Clock loadTime;
    loadTime.restart();

    cout << "main: Starting CarGame v0.0.4..." << endl;
    srand(time(NULL));
    sf::RenderWindow wnd(sf::VideoMode(), sf::String(), sf::Style::Fullscreen);
    //wnd.setFramerateLimit();
    //wnd.setVerticalSyncEnabled(true); //!!!
    sf::Event event;

    cout << "main: Loading game engine..." << endl;

    GameDisplay::drawLoadingProgress("Loading game engine...", &wnd);

    GameDisplay gamedisplay(&wnd);
    Game game;
    GameSound gamesound;

    sf::Clock clock;
    sf::Clock eventClock;
    sf::Clock guiClock;
    sf::Clock tickClock;
    sf::Clock renderClock;
    sf::Clock waitClock;

    cout << "main: Loading took " << loadTime.getElapsedTime().asMilliseconds() << "ms." << endl;

    while(game.isRunning())
    {
        clock.restart();
        eventClock.restart();

        while(wnd.pollEvent(event))
        {
            if(event.type == sf::Event::Closed)
            {
                game.exit(0);
            }

            else if(event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left)
            {
                game.wasReleased = true;
            }

            else if(event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Right)
            {
                if(game.powerCooldown <= 0 && game.powerTime <= 0 && game.powers[game.getCurrentPower()] > 0)
                    game.isPowerUsed = true;
            }

            else if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Space)
            {
                if(game.tutorialStep == 6)
                {
                    game.tutorialStep = 0;
                    game.pause(false);
                }
            }

            else if(game.isGameOver() && event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Return)
            {
                game.loadGame();
            }

            else if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape && !game.isGameOver() && !game.paused())
            {
                cout << "main: Pausing game..." << endl;
                game.displayGui(0);
                game.pause(true);
            }

            else if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::F11)
            {
                game.toggleFullscreen();
            }

            else if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::F3 && event.key.shift)
            {
                game.debug = !game.debug;
            }

            else if(event.type == sf::Event::MouseWheelScrolled)
            {
                game.wheelEvent(event.mouseWheelScroll);
            }
        }
        game.times.timeEvent = eventClock.getElapsedTime();

        if(game.guiCooldown <= 0)
        {
            guiClock.restart();
            game.tickGui(event);
            game.times.timeGui = guiClock.getElapsedTime();
        }

        tickClock.restart();
        loop(&game);
        game.times.timeTick = tickClock.getElapsedTime();

        renderClock.restart();
        gamedisplay.display();
        game.times.timeRender = renderClock.getElapsedTime();

        game.tickTime = clock.getElapsedTime();

        long l = clock.getElapsedTime().asMicroseconds();

        if(l > 10000 && game.guiCooldown == 0)
        {
            cout << "main: Tick took " << l << endl;
        }

        waitClock.restart();
        while(clock.getElapsedTime().asMilliseconds() < 10) {} // 100 ticks/s

        game.realTickTime = clock.getElapsedTime();
        game.times.timeWait = waitClock.getElapsedTime();
    }

    cout << "main: Closing CarGame v0.0.4..." << endl;

    GameDisplay::drawLoadingProgress("Closing...", &wnd);

    game.saveHighScore();
    int i = game.retVal;

    wnd.close();

    return i;
}
