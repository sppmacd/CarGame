#include "CarLorry.h"

CarLorry::CarLorry(float s, int l)
: Car(s,l)
{
    this->maxHealth = 3;
    this->health = 2;
    this->textureName = "car_lorry";
    this->typeId = LORRY;
}
