#include <SFML/Graphics.hpp>
#include "Game.h"
#include "GameDisplay.h"
#include "GuiIngame.h"
#include <cstdlib>
#include <iostream>
#include <string>
#include <ctime>

class GuiMainMenu;

void loop(Game* game)
{
    if(!game->paused()) game->tickNormalGame();

    game->newTick();
}

int main()
{
    srand(time(NULL));
    sf::RenderWindow wnd(sf::VideoMode(1800, 500, 32), "Car Game", sf::Style::Fullscreen);
    sf::Event event;

    GameDisplay gamedisplay(&wnd);
    Game game;

    while(wnd.isOpen())
    {
        while(wnd.pollEvent(event))
        {
            if(event.type == sf::Event::Closed)
            {
                wnd.close();
            }

            if(event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left)
            {
                game.wasReleased = true;
            }

            if(game.isGameOver() && event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Return)
            {
                game.loadGame();
            }

            if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape && !game.isGameOver() && !game.paused())
            {
                game.displayGui(0);
                game.pause(true);
            }
        }

        if(game.guiCooldown <= 0) game.tickGui(event);
        loop(&game);
        gamedisplay.display();
    }

    game.saveHighScore();
    return 0;
}
