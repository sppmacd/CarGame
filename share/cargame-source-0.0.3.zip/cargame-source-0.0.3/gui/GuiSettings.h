#ifndef GUISETTINGS_H
#define GUISETTINGS_H

#include "../Gui.h"

class GuiSettings : public Gui
{
    public:
        GuiSettings();
        virtual ~GuiSettings();

        static void drawGui(sf::RenderWindow* wnd);
        static void onButtonClicked(long button);
        static void onLoad();

    protected:

    private:
        static Button bDone;
        static Button bResetHS;
        static Button bRefreshGD;
};

#endif // GUISETTINGS_H

