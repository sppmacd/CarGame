#include "GuiGameOver.h"
#include "../Game.h"
#include "../GameDisplay.h"
#include <iostream>

using namespace std;

Button GuiGameOver::b1;
Button GuiGameOver::bMainMenu;

void GuiGameOver::onLoad()
{
    GameDisplay* game = GameDisplay::instance;

    addButton(b1 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2), "New Game", 0));
    addButton(bMainMenu = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 + 60), "Return to Menu", 1));
}

void GuiGameOver::drawGui(sf::RenderWindow* wnd)
{
    Gui::drawGui(wnd);

    b1.draw(wnd);
    bMainMenu.draw(wnd);

    Game* game = Game::instance;

    sf::Text gameover = drawString("Game Over!", 100, sf::Vector2f(wnd->getSize().x / 2 - 100, wnd->getSize().y / 2 - 250), sf::Text::Italic);
    gameover.setFillColor(sf::Color(100, 0, 0));
    wnd->draw(gameover);

    char* c2 = new char[10];
    itoa(game->lastTickScore, c2, 10);
    sf::Text sc = drawString(std::string("Your score is ") + std::string(c2), 40, sf::Vector2f(wnd->getSize().x / 2, wnd->getSize().y / 2 - 70));
    sc.setFillColor(sf::Color::Yellow);
    wnd->draw(sc);
}

void GuiGameOver::onButtonClicked(long button)
{
    Game* game = Game::instance;
    if(button == 0)
    {
        game->loadGame();
    }
    else if(button == 1)
    {
        game->displayGui(2); //main menu
    }
}
