#include "GuiSettings.h"
#include "../Game.h"
#include "../GameDisplay.h"
#include <iostream>

Button GuiSettings::bDone;
Button GuiSettings::bResetHS;
Button GuiSettings::bRefreshGD;

void GuiSettings::onLoad()
{
    GameDisplay* game = GameDisplay::instance;

    addButton(bDone = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 + 60), "Done", 0));
    addButton(bResetHS = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2), "Reset Highscore", 1));
    addButton(bRefreshGD = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 - 60), "Refresh Resources", 2));
}

void GuiSettings::drawGui(sf::RenderWindow* wnd)
{
    Gui::drawGui(wnd);

    bDone.draw(wnd);
    bResetHS.draw(wnd);
    bRefreshGD.draw(wnd);

    wnd->draw(drawString("Settings", 30, sf::Vector2f(wnd->getSize().x / 2 - 100, 200)));
}

void GuiSettings::onButtonClicked(long button)
{
    Game* game = Game::instance;

    if(button == 0)
    {
        game->displayGui(2); //main menu
    }
    else if(button == 1)
    {
        remove("highscore.txt");
        game->loadHighScore();
    }
    else if(button == 2)
    {
        GameDisplay::instance->reload();
    }
}

