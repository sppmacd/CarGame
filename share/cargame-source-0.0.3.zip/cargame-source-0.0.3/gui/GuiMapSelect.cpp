#include "GuiMapSelect.h"
#include "../Game.h"
#include "../GameDisplay.h"
#include <iostream>

using namespace std;

Button GuiMapSelect::bMap1;
Button GuiMapSelect::bMap2;
Button GuiMapSelect::bMap3;
Button GuiMapSelect::bMapB1;
Button GuiMapSelect::bMapB2;
Button GuiMapSelect::bMapB3;
Button GuiMapSelect::bReturn;

void GuiMapSelect::onLoad()
{
    GameDisplay* game = GameDisplay::instance;

    addButton(bMap1 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 - 120), "Countryside", 1));
    addButton(bMap2 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 - 60), "Desert", 2));
    addButton(bMap3 = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2), "Forest", 3));

    addButton(bMapB1 = Button(sf::Vector2f(100.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 + 420, game->getRenderWnd()->getSize().y / 2 - 120), "$0", 4));
    addButton(bMapB2 = Button(sf::Vector2f(100.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 + 420, game->getRenderWnd()->getSize().y / 2 - 60), "$100", 5));
    addButton(bMapB3 = Button(sf::Vector2f(100.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 + 420, game->getRenderWnd()->getSize().y / 2), "$400", 6));
    addButton(bReturn = Button(sf::Vector2f(400.f, 40.f), sf::Vector2f(game->getRenderWnd()->getSize().x / 2 - 200, game->getRenderWnd()->getSize().y / 2 + 60), "Return to main menu", 0));
}

void GuiMapSelect::drawGui(sf::RenderWindow* wnd)
{
    bool u1, u2, u3;
    u1 = Game::instance->unlockedLevels & 0b001;
    u2 = Game::instance->unlockedLevels & 0b010;
    u3 = Game::instance->unlockedLevels & 0b100;

    if(!u1)
    {
        bMap1.enabled = false;
        bMapB1.enabled = true;
    }
    else
    {
        bMap1.enabled = true;
        bMapB1.enabled = false;
    }

    if(!u2)
    {
        bMap2.enabled = false;
        bMapB2.enabled = true;
    }
    else
    {
        bMap2.enabled = true;
        bMapB2.enabled = false;
    }

    if(!u3)
    {
        bMap3.enabled = false;
        bMapB3.enabled = true;
    }
    else
    {
        bMap3.enabled = true;
        bMapB3.enabled = false;
    }

    if(Game::instance->getCoins() < 0)
    {
        bMapB1.enabled = false;
    }
    if(Game::instance->getCoins() < 100)
    {
        bMapB2.enabled = false;
    }
    if(Game::instance->getCoins() < 400)
    {
        bMapB3.enabled = false;
    }

    bMap1.draw(wnd);
    bMap2.draw(wnd);
    bMap3.draw(wnd);
    bMapB1.draw(wnd);
    bMapB2.draw(wnd);
    bMapB3.draw(wnd);
    bReturn.draw(wnd);

    wnd->draw(drawString("Map Selection", 30, sf::Vector2f(wnd->getSize().x / 2 - 100, 200)));
}

void GuiMapSelect::onButtonClicked(long button)
{
    if(button == 0)
    {
        Game::instance->displayGui(2); //main menu
    }
    else if(button == 1)
    {
        LevelData data(LevelData::COUNTRYSIDE);
        data.addRarity(Car::LORRY, 3);
        data.addRarity(Car::RARE, 5);
        data.addRarity(Car::BUS, 10);
        data.addRarity(Car::AMBULANCE, 10);
        data.setAcceleration(0.000011f);
        data.setColor(sf::Color::Green);
        data.setTextureName("countryside");
        Game::instance->loadGame(data);
    }

    else if(button == 2)
    {
        LevelData data(LevelData::DESERT);
        data.addRarity(Car::LORRY, 3);
        data.addRarity(Car::RARE, 2);
        data.addRarity(Car::BUS, 3);
        data.addRarity(Car::AMBULANCE, 6);
        data.setAcceleration(0.000008f);
        data.setColor(sf::Color::Yellow);
        data.setTextureName("desert");
        Game::instance->loadGame(data);
    }

    else if(button == 3)
    {
        LevelData data(LevelData::FOREST);
        data.addRarity(Car::LORRY, 3);
        data.addRarity(Car::RARE, 2);
        data.addRarity(Car::BUS, 15);
        data.addRarity(Car::AMBULANCE, 20);
        data.setAcceleration(0.000019f);
        data.setColor(sf::Color(0, 140, 0));
        data.setTextureName("forest");
        Game::instance->loadGame(data);
    }

    else if(button == 4)
    {
        Game::instance->unlockedLevels |= 0b001;
        Game::instance->removeCoins(0);
    }
    else if(button == 5)
    {
        Game::instance->unlockedLevels |= 0b010;
        Game::instance->removeCoins(100);
    }
    else if(button == 6)
    {
        Game::instance->unlockedLevels |= 0b100;
        Game::instance->removeCoins(400);
    }
}

