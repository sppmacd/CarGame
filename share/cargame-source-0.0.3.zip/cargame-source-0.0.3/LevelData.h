#ifndef LevelData_H
#define LevelData_H

#include <vector>
#include <SFML/Graphics.hpp>
#include "Car.h"

using namespace std;

/// Class used with loading game, stores main level data.
class LevelData
{
    public:
        enum MapType
        {
            COUNTRYSIDE,
            DESERT,
            FOREST,
            COUNT
        };

        LevelData(MapType type);
        LevelData() {}
        MapType getMapType();

        void addRarity(Car::TypeId car, int value);
        void setColor(sf::Color c);
        void setTextureName(sf::String name);
        void setAcceleration(float f);

        sf::Color getColor();
        sf::String getTextureName();
        float getAcceleration();
        int getCarRarity(Car::TypeId car);

    private:
        /// Internal array to store car rarity.
        vector<int> carRarity;
        sf::Color mapColor;
        sf::String textureName;
        float acc;
        MapType mapType;
};

#endif // LevelData_H
