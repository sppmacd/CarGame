#ifndef BUTTON_H
#define BUTTON_H

#include <SFML/Graphics.hpp>
#include <string>

using namespace std;

class Gui;

class Button
{
    public:
        Button(sf::Vector2f size, sf::Vector2f pos, string text, int id);
        Button() {this->id = -1;}

        sf::Vector2f getPos() {return this->bPos;}
        sf::Vector2f getSize() {return this->bSize;}
        string getText() {return this->bText;}
        sf::Text drawString(string, int, sf::Vector2f, sf::Text::Style);

        virtual void draw(sf::RenderWindow* wnd);

        bool isMouseOver;
        bool enabled;
        long id;

        bool operator==(Button r)
        {
            return r.id == this->id;
        }

    protected:

    private:
        sf::Vector2f bSize;
        sf::Vector2f bPos;
        string bText;
        sf::Color bColor;
};

#endif // BUTTON_H
