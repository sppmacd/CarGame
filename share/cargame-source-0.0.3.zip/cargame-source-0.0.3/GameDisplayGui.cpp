#include "GameDisplay.h"
#include "Game.h"
#include "GuiIngame.h"
#include "GuiGameOver.h"
#include "GuiMainMenu.h"
#include "GuiSettings.h"
#include "GuiMapSelect.h"

void GameDisplay::drawGui()
{
    Game* game = Game::instance;

    /*sf::Text text = this->drawString("Click Esc to pause", 40, sf::Vector2f(6.f, 6.f), sf::Text::Bold);
    text.setFillColor(sf::Color::Red);
    this->renderWnd->draw(text);*/

    if(!game->paused()) //is not paused
    {
        char* c1 = new char[10];
        itoa(game->getScore(), c1, 10);

        sf::Text sc = this->drawString(c1, 70, sf::Vector2f(this->renderWnd->getSize().x / 2 - 100, 6.f), sf::Text::Bold);
        sc.setFillColor(sf::Color::Cyan);
        this->renderWnd->draw(sc);

        char* c2 = new char[10];
        itoa(game->highScore, c2, 10);

        sf::Text sc2 = this->drawString(std::string("HIGHSCORE: ") + std::string(c2), 80, sf::Vector2f(this->renderWnd->getSize().x / 2 + 100, 6.f), sf::Text::Bold);
        sc2.setFillColor(sf::Color::Blue);
        this->renderWnd->draw(sc2);
    }

    switch(game->displayedGui) //other GUI in this switch
    {
        case 0: GuiIngame::drawGui(this->renderWnd); break;
        case 1: GuiGameOver::drawGui(this->renderWnd); break;
        case 2: GuiMainMenu::drawGui(this->renderWnd); break;
        case 3: GuiSettings::drawGui(this->renderWnd); break;
        case 4: GuiMapSelect::drawGui(this->renderWnd); break;
    }

    if(game->guiCooldown > 0)
    {
        sf::RectangleShape rect((sf::Vector2f) this->renderWnd->getSize());
        rect.setFillColor(sf::Color(25, 20, 20, 250));
        this->renderWnd->draw(rect);

        char* c1 = new char[10];

        int x = (25 - game->guiCooldown) * 4;

        itoa(x, c1, 10);

        sf::Text sc2 = this->drawString("Loading... " + std::string(c1) + "%", 80, sf::Vector2f(this->renderWnd->getSize().x / 2, this->renderWnd->getSize().y / 2));
        sc2.setFillColor(sf::Color::White);
        this->renderWnd->draw(sc2);
    }

    char* c3 = new char[10];
    itoa(game->getCoins(), c3, 10);

    sf::Sprite coin(this->texturesByName.find("coin")->second);
    coin.setPosition(50.f, 32.f);
    this->renderWnd->draw(coin);

    sf::Text sc2 = this->drawString(std::string(c3), 80, sf::Vector2f(100.f, 6.f), sf::Text::Bold);
    sc2.setFillColor(sf::Color::Blue);
    this->renderWnd->draw(sc2);
}
