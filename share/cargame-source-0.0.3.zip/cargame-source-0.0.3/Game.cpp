#include "Game.h"
#include "CarLorry.h"
#include "CarRare.h"
#include <cmath>
#include <iostream>
#include <fstream>
#include "Gui.h"
#include "GuiGameOver.h"
#include "GuiIngame.h"
#include "GuiMainMenu.h"
#include "GuiSettings.h"
#include "GameDisplay.h"
#include "GuiMapSelect.h"

Game* Game::instance;

Game::Game()
: displayedGui(-1)
{
    instance = this;
    this->pause(true);
    this->displayGui(2); //main menu
    this->loadHighScore();
}

void Game::loadHighScore()
{
    std::ifstream file;
    file.open("highscore.txt");

    if(file.good())
    {
        file >> this->highScore >> this->playerCoins >> this->unlockedLevels;
    }
    else
    {
        this->highScore = 0;
        this->playerCoins = 0;
        this->unlockedLevels = 0b0;
    }
}

void Game::saveHighScore()
{
    std::ofstream file;
    file.open("highscore.txt");

    file << this->highScore << " " << this->getCoins() << " " << this->unlockedLevels;
}

void Game::loadGame(LevelData level)
{
    this->level = level;

    this->lastTickScore = 0;
    this->cameraPos = 0;
    this->tickCount = 0;
    this->gameSpeed = 0.f;
    this->score = 0;
    this->gameOver = false;
    this->isGuiLoaded = false;
    this->cars.clear();
    this->pause(false);
    this->closeGui();
}

void Game::loadGame()
{
    this->lastTickScore = 0;
    this->cameraPos = 0;
    this->tickCount = 0;
    this->gameSpeed = 0.f;
    this->score = 0;
    this->gameOver = false;
    this->isGuiLoaded = false;
    this->cars.clear();
    this->pause(false);
    this->closeGui();
}

Game::~Game()
{
}

void Game::tickGui(sf::Event& event)
{
    this->tickEventMouseMove(sf::Vector2f(sf::Mouse::getPosition(*GameDisplay::instance->getRenderWnd())));

    if(event.type == sf::Event::MouseButtonPressed)
    {
        this->tickEventMouseClick(sf::Vector2f(sf::Mouse::getPosition(*GameDisplay::instance->getRenderWnd())));
    }
}

void Game::tickEventMouseMove(sf::Vector2f pos)
{
    if(this->isGuiLoaded)
    {
        Gui::onMouseMove(pos);
    }
}

void Game::tickEventMouseClick(sf::Vector2f pos)
{
    if(this->isGuiLoaded)
    {
        if(this->displayedGui == 0)
            GuiIngame::onButtonClicked(Gui::onMouseClick(pos).id);
        else if(this->displayedGui == 1)
            GuiGameOver::onButtonClicked(Gui::onMouseClick(pos).id);
        else if(this->displayedGui == 2)
            GuiMainMenu::onButtonClicked(Gui::onMouseClick(pos).id);
        else if(this->displayedGui == 3)
            GuiSettings::onButtonClicked(Gui::onMouseClick(pos).id);
        else if(this->displayedGui == 4)
            GuiMapSelect::onButtonClicked(Gui::onMouseClick(pos).id);
    }
}

void Game::setGameOver()
{
    this->gameOver = true;
    this->pause(true);
    this->saveHighScore();
    this->displayGui(1);
}

void Game::moveCamera()
{
    this->cameraPos += this->gameSpeed * 4.5;
}

void Game::displayGui(int gui)
{
    this->displayedGui = gui;

    Gui::onClose();

    if(gui == 0)
        GuiIngame::onLoad();
    else if(gui == 1)
        GuiGameOver::onLoad();
    else if(gui == 2)
        GuiMainMenu::onLoad();
    else if(gui == 3)
        GuiSettings::onLoad();
    else if(gui == 4)
        GuiMapSelect::onLoad();

    this->isGuiLoaded = true;
    this->guiCooldown = 50;
}

void Game::closeGui()
{
    Gui::onClose();
    this->displayedGui = -1;
    this->isGuiLoaded = false;
}

void Game::toggleFullscreen()
{
    sf::RenderWindow* wnd = GameDisplay::instance->getRenderWnd();

    if(this->fullscreen)
    {
        wnd->close();
        wnd->create(sf::VideoMode(1920, 1080, 32), "Car Game");
        this->fullscreen = false;
    }
    else
    {
        wnd->close();
        wnd->create(sf::VideoMode(), "Car Game", sf::Style::Fullscreen);
        this->fullscreen = true;
    }
}

void Game::addCoins(long v)
{
    this->playerCoins += v;
}

void Game::removeCoins(long v)
{
    this->playerCoins -= v;
}

long Game::getCoins()
{
    return this->playerCoins;
}
