#include "GameDisplay.h"
#include "Game.h"
#include <iostream>

GameDisplay* GameDisplay::instance;

GameDisplay::GameDisplay(sf::RenderWindow* wnd)
: renderWnd(wnd)
{
    instance = this;

    this->reload();
}

void GameDisplay::clearTextures()
{
    this->texturesByName.clear();
}

void GameDisplay::reload()
{
    this->clearTextures();

    this->addTexture("car");
    this->addTexture("car_lorry");
    this->addTexture("car_bus");
    this->addTexture("car_ambulance");
    this->addTexture("bg_countryside");
    this->addTexture("bg_desert");
    this->addTexture("bg_forest");
    this->addTexture("coin");

    sf::Font font;
    font.loadFromFile("res/font.ttf");
    this->guiFont = font;
}

void GameDisplay::addTexture(string name)
{
    sf::Texture tx;
    tx.loadFromFile("res/" + name + ".png");
    this->texturesByName.insert(std::pair<string,sf::Texture>(name,tx));
}

GameDisplay::~GameDisplay()
{
    //dtor
}

void GameDisplay::display()
{
    Game* game = Game::instance;

    if(!game->paused())
    {
        this->drawGame();
    }
    else
    {
        if(game->displayedGui == 2)
            this->renderWnd->clear(sf::Color(25, 20, 20));
        else
            this->renderWnd->clear(sf::Color(50, 40, 40));
    }

    this->drawGui();

    this->renderWnd->display();
}

sf::Text GameDisplay::drawString(string tx, int height, sf::Vector2f pos, sf::Text::Style style)
{
    sf::Text text = sf::Text(tx, this->guiFont);
    text.setPosition(pos);
    text.setCharacterSize(height);
    text.setStyle(style);

    return text;
}

void GameDisplay::drawGame()
{
    Game* game = Game::instance;

    this->renderWnd->clear(game->getLevelColor());

            // BACKGROUND
    sf::Sprite bg(this->texturesByName.find("bg_" + game->level.getTextureName().toAnsiString())->second);
    bg.setScale(1920.0f, 2.0f);
    bg.setPosition(0.f, 200.f);
    this->renderWnd->draw(bg);

    // CARS
    sf::Sprite car(this->texturesByName.find("car")->second);
    car.setOrigin(50.f, 20.f);
    car.setScale(2.0f, 2.0f);

    sf::RectangleShape rect1;
    rect1.setFillColor(sf::Color::Green);
    sf::RectangleShape rect2;
    rect2.setFillColor(sf::Color::Red);

    for(unsigned int i = 0; i < game->cars.size(); i++)
    {
        Car carobj = game->cars[i];

        rect1.setSize(sf::Vector2f((((float)carobj.health+1) / (float)carobj.maxHealth) * 30.f, 3.f));
        rect2.setSize(sf::Vector2f(30.f - ((((float)carobj.health+1) / (float)carobj.maxHealth) * 30.f), 3.f));

        car.setPosition(carobj.getScreenPos());
        car.setColor(carobj.getColor());

        car.setTexture(this->texturesByName.find(carobj.getTextureName())->second);

        if(carobj.isDestroying())
        {
            car.setRotation(carobj.destroyTick * 3.6f);
            car.setScale(carobj.destroyTick / 100.f, carobj.destroyTick / 100.f);
        }

        this->renderWnd->draw(car);

        car.setScale(2.0f, 2.0f);
        car.setRotation(0.f);

        rect1.setPosition(car.getPosition().x, car.getPosition().y + 30);
        rect2.setPosition(car.getPosition().x + rect1.getSize().x, car.getPosition().y + 30);

        if(!game->cars[i].isDestroying())
        {
            this->renderWnd->draw(rect1);
            this->renderWnd->draw(rect2);
        }
    }
}
