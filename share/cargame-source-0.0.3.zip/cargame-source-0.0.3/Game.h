#ifndef GAME_H
#define GAME_H

#include <vector>
#include "Car.h"
#include "Gui.h"
#include "LevelData.h"

using namespace std;

class Game
{
    public:
        Game();
        virtual ~Game();

        vector<Car> cars;
        void addCar(Car car);
        void updateCars();
        void moveCamera();
        void loadGame(LevelData level);
        void loadGame();
        void loadGameLevel();
        void tickNormalGame();
        void loadHighScore();
        void saveHighScore();
        void newTick();
        bool isGameOver() {return this->gameOver; }
        int getScore() {return this->score; }
        void setGameOver();
        void pause(bool s) {this->gamePaused = s; }
        bool paused() {return this->gamePaused; }
        void tickGui(sf::Event& event);
        void toggleFullscreen();
        void addCoins(long v);
        void removeCoins(long v);
        long getCoins();

        static Game* instance;
        int tickCount;
        bool wasReleased;
        long lastTickScore;
        long highScore;
        bool isGuiLoaded;
        int displayedGui;
        int guiCooldown;
        LevelData level;

        ///saved in bytes :D
        int unlockedLevels;

        void displayGui(int gui);
        void closeGui();
        sf::Color getLevelColor() {return this->level.getColor();}

    protected:

    private:
        int cameraPos;
        float gameSpeed;
        long score;
        bool gameOver;
        bool gamePaused;
        bool fullscreen;
        long playerCoins;

        void tickEventMouseMove(sf::Vector2f pos);
        void tickEventMouseClick(sf::Vector2f pos);
};

#endif // GAME_H
