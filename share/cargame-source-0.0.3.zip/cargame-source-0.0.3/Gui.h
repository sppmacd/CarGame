#ifndef GUI_H
#define GUI_H

#include <SFML/Graphics.hpp>
#include <vector>
#include "Button.h"
#include <cmath>
#include <string>
#include <iostream>

using namespace std;

class Gui
{
    public:
        static void drawGui(sf::RenderWindow* wnd);
        static Button onMouseClick(sf::Vector2f vec);
        static void onMouseMove(sf::Vector2f vec);
        static void onButtonClicked(long button);
        static void addButton(Button& button);
        static void onLoad();
        static void onClose();

    protected:
        static sf::Text drawString(string tx, int height, sf::Vector2f pos, sf::Text::Style style = sf::Text::Regular);

    private:
        static vector<Button*> buttons;
};

#endif // GUI_H
