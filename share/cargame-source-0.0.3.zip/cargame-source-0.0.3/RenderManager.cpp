#include "RenderManager.h"

RenderManager::RenderManager(Game* game)
{
    //ctor
}

RenderManager::~RenderManager()
{
    //dtor
}
