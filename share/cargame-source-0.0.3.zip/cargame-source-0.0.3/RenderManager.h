#ifndef RENDERMANAGER_H
#define RENDERMANAGER_H

#include "Game.h"

class RenderManager
{
    public:
        RenderManager(Game* game);
        virtual ~RenderManager(); //todo

    protected:

    private:
        Game* gameInst;
};

#endif // RENDERMANAGER_H
