#include "LevelData.h"

void LevelData::addRarity(Car::TypeId car, int value)
{
    this->carRarity.push_back(value);
}

float LevelData::getAcceleration()
{
    return this->acc;
}

int LevelData::getCarRarity(Car::TypeId car)
{
    return this->carRarity[car];
}

sf::Color LevelData::getColor()
{
    return this->mapColor;
}

LevelData::MapType LevelData::getMapType()
{
    return this->mapType;
}

sf::String LevelData::getTextureName()
{
    return this->textureName;
}

LevelData::LevelData(MapType type)
{
    this->mapType = type;
}

void LevelData::setAcceleration(float f)
{
    this->acc = f;
}

void LevelData::setColor(sf::Color c)
{
    this->mapColor = c;
}

void LevelData::setTextureName(sf::String name)
{
    this->textureName = name;
}
