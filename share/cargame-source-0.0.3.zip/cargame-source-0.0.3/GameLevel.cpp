#include "Game.h"
#include "CarLorry.h"
#include "CarRare.h"
#include "CarBus.h"
#include "CarAmbulance.h"

void Game::addCar(Car car)
{
    this->cars.push_back(car);
}

void Game::updateCars()
{
    this->lastTickScore = this->score;

    if(!this->cars.empty())
    {
        bool _break = false;
        for(unsigned int i = 0; i < this->cars.size() || _break; i++)
        {
            Car* car = &(this->cars[i]);
            car->move(this->gameSpeed / 2);

            if(car->isDestroying())
            {
                if(car->tickDestroy()) //lagi!
                {
                    car->setToErase();
                }
            }

            else
            {
                if(car->carRelativeToScreen < -50.f)
                {
                    car->setToErase();
                    this->setGameOver();
                }

                if(abs(car->getScreenPos().x - sf::Mouse::getPosition().x) < 100.f && abs(car->getScreenPos().y - sf::Mouse::getPosition().y) < 40.f && this->wasReleased)
                {
                    car->makeDestroy();
                    if(car->typeId == Car::RARE)
                        this->score += 2;
                    else
                        this->score += 1;

                    if(this->score % 2 == 0)
                    {
                        this->addCoins(1);
                    }

                    continue;
                }
            }

            if(car->canErase)
            {
                this->cars.erase(this->cars.begin() + i);
            }
        }
        this->wasReleased = false; // This was moved from destroy code to prevent bug (gos2) with destroying
    }
}

void Game::tickNormalGame()
{
    if(this->tickCount % 450 == 199)
    {
        Car car;

        if(rand() % this->level.getCarRarity(Car::LORRY) == 0)
        {
            car = CarLorry(1.7f, rand() % 3);
            int c = rand() % 56 + 200;
            car.setColor(sf::Color(c, c, c));
        }
        else if(rand() % this->level.getCarRarity(Car::RARE) == 0)
        {
            car = CarRare(1.7f, rand() % 3);
            int c = rand() % 56 + 200;
            car.setColor(sf::Color(c, 50, 50));
        }
        else if(rand() % this->level.getCarRarity(Car::BUS) == 0)
        {
            car = CarBus(1.7f, rand() % 3);
            int c = rand() % 200 + 56;
            car.setColor(sf::Color(c, c, 50));
        }
        else if(rand() % this->level.getCarRarity(Car::AMBULANCE) == 0)
        {
            car = CarAmbulance(1.7f, rand() % 3);
            car.setColor(sf::Color(230, 230, 230));
        }
        else
        {
            car = Car(1.7f, rand() % 3);
            car.setColor(sf::Color(((rand() % 8)*32)-1, ((rand() % 8)*32)-1, ((rand() % 8)*32)-1));
        }

        this->addCar(car);
    }

    if(this->getScore() < 0)
    {
        this->setGameOver();
    }

    this->updateCars();

    if(this->score > this->highScore)
    {
        this->highScore = this->score;
    }

    this->moveCamera();
}

void Game::newTick()
{
    if(!this->isGuiLoaded)
    {
        this->gameSpeed += this->level.getAcceleration();
        ++tickCount;
    }

    if(this->guiCooldown > 0) this->guiCooldown--;
}

void Game::loadGameLevel()
{

}
