#ifndef GAMEDISPLAY_H
#define GAMEDISPLAY_H

#include <SFML/Graphics.hpp>
#include <string>
#include <map>
#include <iostream>

using namespace std;

class GameDisplay
{
    public:
        GameDisplay(sf::RenderWindow* wnd);
        virtual ~GameDisplay();

        void drawGui();
        void display();
        void drawGame();
        void reload();
        void clearTextures();

        sf::Text drawString(string tx, int height, sf::Vector2f pos, sf::Text::Style style = sf::Text::Regular);

        sf::RenderWindow* getRenderWnd() {return this->renderWnd;}

        void addTexture(string name);
        sf::Texture getTexture(string name);

        static GameDisplay* instance;

    protected:

    private:
        sf::RenderWindow* renderWnd;

        sf::Texture unknownTexture;
        map<string, sf::Texture> texturesByName;

        sf::Font guiFont;
};

#endif // GAMEDISPLAY_H
