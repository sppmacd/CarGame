#ifndef GAMEDISPLAY_H
#define GAMEDISPLAY_H

#include <SFML/Graphics.hpp>
#include <string>
#include <map>

using namespace std;

class GameDisplay
{
    public:
        GameDisplay(sf::RenderWindow* wnd);
        virtual ~GameDisplay();

        void drawGui();
        void display();
        void drawGameOverGui();
        void drawGame();
        void drawIngameGui();
        sf::Text drawString(string tx, int height, sf::Vector2f pos, sf::Text::Style style = sf::Text::Regular);

        void addTexture(string name);
        sf::Texture getTexture(string name);

    protected:

    private:
        sf::RenderWindow* renderWnd;

        sf::Texture unknownTexture;
        map<string, sf::Texture> texturesByName;

        sf::Font guiFont;
};

#endif // GAMEDISPLAY_H
