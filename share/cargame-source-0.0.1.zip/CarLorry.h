#ifndef CARLORRY_H
#define CARLORRY_H

#include "Car.h"

class CarLorry : public Car
{
    public:
        CarLorry(float s, int l);
        virtual ~CarLorry() {}

    protected:

    private:
};

#endif // CARLORRY_H
