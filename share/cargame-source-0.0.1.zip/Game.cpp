#include "Game.h"
#include "CarLorry.h"
#include <cmath>
#include <iostream>
#include <fstream>

Game* Game::instance;

Game::Game()
{
    instance = this;
    this->loadGame();
}

void Game::loadHighScore()
{
    std::ifstream file;
    file.open("highscore.txt");

    if(file.good())
    {
        file >> this->highScore;
    }
    else
    {
        this->highScore = 0;
    }
}

void Game::saveHighScore()
{
    std::ofstream file;
    file.open("highscore.txt");

    file << this->highScore;
}

void Game::tickNormalGame()
{
    if(!this->gamePaused)
    {
        if(this->tickCount % 300 == 199)
        {
            Car car;

            if(rand() % 3 == 0)
            {
                car = CarLorry((rand() % 5 + 65) / 29.f, rand() % 3);
                int c = rand() % 256 + 200;
                car.setColor(sf::Color(c, c, c));
            }
            else
            {
                car = Car((rand() % 5 + 65) / 29.f, rand() % 3);
                car.setColor( sf::Color(
                                   ((rand() % 8)*32)-1,
                                   ((rand() % 8)*32)-1,
                                   ((rand() % 8)*32)-1));
            }

            this->addCar(car);
        }

        this->updateCars();

        if(this->score > this->highScore)
        {
            this->highScore = this->score;
        }

        this->moveCamera();
    }
}

void Game::newTick()
{
    this->gameSpeed += 0.00011;
    ++tickCount;
}

void Game::loadGame()
{
    this->lastTickScore = 0;
    this->cameraPos = 0;
    this->tickCount = 0;
    this->gameSpeed = 0.f;
    this->score = 0;
    this->gameOver = false;
    this->cars.clear();
    this->loadHighScore();
}

Game::~Game()
{
    //dtor
}

void Game::addCar(Car car)
{
    this->cars.push_back(car);
}

void Game::updateCars()
{
    this->lastTickScore = this->score;

    if(!this->cars.empty())
    {
        bool _break = false;
        for(unsigned int i = 0; i < this->cars.size() || _break; i++)
        {
            Car* car = &(this->cars[i]);
            car->move(this->gameSpeed);

            if(car->isDestroying())
            {
                if(car->tickDestroy()) //lagi!
                {
                    car->setToErase();
                }
            }

            else
            {
                if(car->carRelativeToScreen < -50.f)
                {
                    car->setToErase();
                    this->setGameOver();
                }

                if(abs(car->getScreenPos().x - sf::Mouse::getPosition().x) < 100.f && abs(car->getScreenPos().y - sf::Mouse::getPosition().y) < 40.f && this->wasReleased)
                {
                    car->makeDestroy();
                    this->score++;

                    continue;
                }
            }

            if(car->canErase)
            {
                this->cars.erase(this->cars.begin() + i);
            }
        }
        this->wasReleased = false; // This was moved from destroy code to prevent bug (gos2) with destroying
    }
}

void Game::setGameOver()
{
    this->gameOver = true;
    this->saveHighScore();
}

void Game::moveCamera()
{
    this->cameraPos += this->gameSpeed * 6;
}
