#ifndef GAME_H
#define GAME_H

#include <vector>
#include "Car.h"

using namespace std;

class Game
{
    public:
        Game();
        virtual ~Game();

        vector<Car> cars;
        void addCar(Car car);
        void updateCars();
        void moveCamera();
        void loadGame();
        void tickNormalGame();
        void loadHighScore();
        void saveHighScore();
        void newTick();
        bool isGameOver() {return this->gameOver; }
        int getScore() {return this->score; }
        void setGameOver();
        void pause(bool s) {this->gamePaused = s; }
        bool paused() {return this->gamePaused; }

        static Game* instance;
        int tickCount;
        bool wasReleased;
        int lastTickScore;
        int highScore;

    protected:

    private:
        int cameraPos;
        float gameSpeed;
        int score;
        bool gameOver;
        bool gamePaused;
};

#endif // GAME_H
