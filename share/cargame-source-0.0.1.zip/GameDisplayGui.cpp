#include "GameDisplay.h"
#include "Game.h"

void GameDisplay::drawGameOverGui()
{
    Game* game = Game::instance;

    sf::Text gameover = this->drawString("Game Over!", 100, sf::Vector2f(100, this->renderWnd->getSize().y / 2 - 50), sf::Text::Italic);
    gameover.setFillColor(sf::Color(100, 0, 0));
    this->renderWnd->draw(gameover);

    sf::Text cstr = this->drawString("Click Space to restart", 70, sf::Vector2f(100, this->renderWnd->getSize().y / 2 + 50), sf::Text::Italic);
    cstr.setFillColor(sf::Color(50, 100, 0));
    this->renderWnd->draw(cstr);

    char* c2 = new char[10];
    itoa(game->lastTickScore, c2, 10);
    sf::Text sc = this->drawString(std::string("Your score is ") + std::string(c2), 40, sf::Vector2f(this->renderWnd->getSize().x / 2, this->renderWnd->getSize().y / 2 + 130));
    sc.setFillColor(sf::Color::Yellow);
    this->renderWnd->draw(sc);
}

void GameDisplay::drawIngameGui()
{
    sf::RectangleShape bg((sf::Vector2f) this->renderWnd->getSize());
    bg.setFillColor(sf::Color(25, 20, 20, 200));
    this->renderWnd->draw(bg);

    sf::Text sc = this->drawString("Press Enter to continue\nPress Esc to quit", 40, sf::Vector2f(this->renderWnd->getSize().x / 2, this->renderWnd->getSize().y / 2));
    sc.setFillColor(sf::Color(150, 140, 130));
    this->renderWnd->draw(sc);

    sf::Text gm = this->drawString("Game menu", 60, sf::Vector2f(this->renderWnd->getSize().x / 2 - 30, this->renderWnd->getSize().y / 2 - 100));
    gm.setFillColor(sf::Color(170, 160, 140));
    this->renderWnd->draw(gm);
}

void GameDisplay::drawGui()
{
    Game* game = Game::instance;

    sf::Text text = this->drawString("Click Esc to pause", 40, sf::Vector2f(6.f, 6.f), sf::Text::Bold);
    text.setFillColor(sf::Color::Red);
    this->renderWnd->draw(text);

    if(!game->isGameOver())
    {
        char* c1 = new char[10];
        itoa(game->getScore(), c1, 10);

        sf::Text sc = this->drawString(c1, 70, sf::Vector2f(this->renderWnd->getSize().x / 2 - 100, 6.f), sf::Text::Bold);
        sc.setFillColor(sf::Color::Cyan);
        this->renderWnd->draw(sc);

        char* c2 = new char[10];
        itoa(game->highScore, c2, 10);

        sf::Text sc2 = this->drawString(std::string("HIGHSCORE: ") + std::string(c2), 80, sf::Vector2f(this->renderWnd->getSize().x / 2 + 100, 6.f), sf::Text::Bold);
        sc2.setFillColor(sf::Color::Blue);
        this->renderWnd->draw(sc2);
    }
    else
    {
        this->drawGameOverGui();
    }
}
