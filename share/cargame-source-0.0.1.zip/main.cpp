#include <SFML/Graphics.hpp>
#include "Game.h"
#include "GameDisplay.h"
#include <cstdlib>
#include <iostream>
#include <string>

void loop(Game* game)
{
    if(!game->isGameOver()) game->tickNormalGame();

    if(game->getScore() < 0)
    {
        game->setGameOver();
    }

    game->newTick();
}

int main()
{
    sf::RenderWindow wnd(sf::VideoMode(1800, 500, 32), "Car Game", sf::Style::Fullscreen);
    sf::Event event;

    GameDisplay gamedisplay(&wnd);
    Game game;
    bool fullscreen = true;

    while(wnd.isOpen())
    {
        while(wnd.pollEvent(event))
        {
            if(event.type == sf::Event::Closed)
            {
                wnd.close();
            }

            if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape && (game.paused() || game.isGameOver()))
            {
                wnd.close();
            }

            if(event.type == sf::Event::MouseButtonReleased && event.mouseButton.button == sf::Mouse::Left)
            {
                game.wasReleased = true;
            }

            if(game.isGameOver() && event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Space)
            {
                game.loadGame();
            }

            if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::F11)
            {
                if(fullscreen)
                {
                    wnd.close();
                    wnd.create(sf::VideoMode(1920, 1080, 32), "Car Game");
                    fullscreen = false;
                }
                else
                {
                    wnd.close();
                    wnd.create(sf::VideoMode(), "Car Game", sf::Style::Fullscreen);
                    fullscreen = true;
                }
            }

            if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape && !game.isGameOver())
            {
                game.pause(true);
            }

            if(event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Return && game.paused())
            {
                game.pause(false);
            }
        }

        loop(&game);
        gamedisplay.display();
    }

    return 0;
}
